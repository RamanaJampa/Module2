


CREATE TABLE product(product_code NUMBER PRIMARY KEY,product_name VARCHAR2(20),product_category VARCHAR2(20),product_description VARCHAR2(30),product_price NUMBER);


SQL> INSERT INTO product VALUES(1001,'iPhone','Electronics','Smart Phone',35000);

1 row created.

SQL> INSERT INTO product VALUES(1002,'LEDTV','Electronics','TV',45000);

1 row created.

SQL> INSERT INTO product VALUES(1003,'Teddy','Toys','Soft toy',800);

1 row created.

SQL> INSERT INTO product VALUES(1004,'Pencil','Stationary','A pack of 12 pencils',80);

1 row created.


SQL> CREATE TABLE sales(sales_id NUMBER,product_code NUMBER REFERENCES product(product_code),quantity NUMBER,sales_date DATE,line_total NUMBER);

