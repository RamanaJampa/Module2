package com.capgemini.salesmanagement.exception;

public class ProductException extends Exception{
	
	public ProductException(String message) {
		
		System.out.println(message);
		
	}

}
